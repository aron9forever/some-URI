import { Routes, CanActivate } from '@angular/router';

import { DashboardComponent } from './dashboard.component';
import {AuthGuard} from '../session/auth.guard';

export const DashboardRoutes: Routes = [{
  path: '',
  component: DashboardComponent,
  canActivate: [AuthGuard]
}];
