import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent { 
  constructor(private http: HttpClient, public jwtHelper: JwtHelperService) {

  }

  runTest() {
    return this.http.post(environment.apiUrl + 'auth/me', {})
      .subscribe( data => { console.log(data); });
  }
}
