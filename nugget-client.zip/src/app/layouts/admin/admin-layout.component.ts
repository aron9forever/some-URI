import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {NavigationEnd, Router} from '@angular/router';
import {MenuItems} from '../../modules/Common/menu-items/menu-items';
import {Subject, Subscription} from 'rxjs';
import {filter, takeUntil} from 'rxjs/operators';

import {TranslateService} from '@ngx-translate/core';
import {AuthService, RoleTypes} from '../../session/auth.service';
import swal from 'sweetalert2';
import {AppSettingsService} from '../../modules/Common/services/app-settings/app-settings.service';
import {ContentLoadingOverlayService} from '../../modules/Common/services/content-loading-overlay/content-loading-overlay.service';
import {LanguageBookService} from '../../modules/Common/services/language-book/language-book.service';


export interface BadgeItem {
  type: string;
  value: string;
}

export interface ChildrenItems {
  state;
  name: string;
  type?: string;
}

export interface Menu {
  state;
  name: string;
  type: string;
  icon: string;
  condition?: any;
  badge?: BadgeItem[];
  children?: ChildrenItems[];
}

@Component({
  selector: 'app-layout',
  templateUrl: './admin-layout.component.html'
})
export class AdminLayoutComponent implements OnInit, OnDestroy {
  unsubscribeAll = new Subject();
  private _router: Subscription;

  url: string;
  showSettings = false;
  dark: boolean;
  boxed: boolean;
  collapseSidebar: boolean;
  compactSidebar: boolean;
  sidebarBg = true;
  currentLang = 'en';
  layoutDir = 'ltr';
  
  menuLayout: any = 'vertical-menu';
  selectedSidebarImage: any = 'bg-5';
  selectedSidebarColor: any = 'sidebar-default';
  selectedHeaderColor: any = 'header-default';
  collapsedClass: any = 'side-panel-opened';

  MENUITEMS : Menu[] = [];

  @ViewChild('sidemenu') sidemenu;
  @ViewChild('appContainer') appContainer;
  public overlay;

  constructor(
    private router: Router,
    public menuItems: MenuItems,
    public translate: TranslateService,
    public loadingOverlay: ContentLoadingOverlayService,
    public authService: AuthService,
    public settingsService: AppSettingsService,
    private lang: LanguageBookService,
  ) {
    this.authService.authStateChangedStream
      .pipe(takeUntil(this.unsubscribeAll))
      .subscribe(user => {
      this.constructMenu();
    });
  }

  ngOnInit(): void {
    this._router = this.router.events
      .pipe(takeUntil(this.unsubscribeAll))
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
      this.url = event.url;
      if (this.isOver()) {
        this.sidemenu.close();
      }
    });

    this.forceSettings();
    this.currentLang = this.lang.currrentLang;
  }

  private constructMenu() {
    this.MENUITEMS = [
      {
        state: ['welcome'],
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.ENTRY',
        type: 'link',
        condition: !this.authService.isLoggedIn(),
        icon: 'input'
      },
      {
        state: ['home'],
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.HOME',
        type: 'link',
        condition: this.authService.isLoggedIn(),
        icon: 'home'
      },
      {
        state: ['pickup', 'list'],
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.PICKUP_LIST',
        type: 'link',
        condition: true,
        icon: 'schedule'
      },
      {
        state: ['pickup', 'daily-list'],
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.PICKUP_DAILYLIST',
        type: 'link',
        condition: this.authService.isLoggedIn(),
        icon: 'today'
      },
      {
        state: ['pickup', 'create'],
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.PICKUP_CREATE',
        type: 'link',
        condition: this.authService.isLoggedIn(),
        icon: 'input'
      },
      {
        state: ['task', 'work-view'],
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.ACTIVITY_TABLE',
        condition: this.authService.isLoggedIn() && this.authService.hasRole(RoleTypes.WORKER),
        type: 'link',
        icon: 'assignment'
      },
      {
        state: ['task', 'admin-overview'],
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.ACTIVITY_OVERVIEW',
        condition: this.authService.isLoggedIn() && this.authService.hasRole(RoleTypes.ADMIN),
        type: 'link',
        icon: 'dashboard'
      },
      {
        state: '',
        name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.ADMIN',
        type: 'sub',
        condition: this.authService.isLoggedIn() && this.authService.hasRole(RoleTypes.ADMIN),
        icon: 'verified_user',
        children: [
          {state: ['user', 'manage'], name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.MANAGE_USERS'},
          {state: ['logs', 'admin-overview'], name: 'LANG.INTERFACE.SIDE_MENU.BUTTONS.USER_LOGS'},
        ]
      },
    ];
  }

  logout() {
    this.authService.logout();
    (swal({
      title: this.lang.book.AUTH.ALERTS.LOGOUT.TITLE,
      text: this.lang.book.AUTH.ALERTS.LOGOUT.BODY,
      type: 'success',
      confirmButtonText: this.lang.book.BUTTONS.OK,
      timer: 3000,
      heightAuto: false,
    }) as any).then( () => {
      this.router.navigate(['/welcome']);
    }, () => {
      this.router.navigate(['/welcome']);
    });
  }

  test() {
    console.log(this.authService.isLoggedIn())
  }

  conditionTrue(m) {
    return (typeof m.condition === 'undefined') || m.condition;
  }

  forceSettings() {
      this.onSelectedSidebarColor('sidebar-opaque');
      //this.settingsService.isVolumeEnabled ? Howler.volume(1.0) : Howler.volume(0.0);
  }

  ngOnDestroy() {
    this.unsubscribeAll.next();
    this.unsubscribeAll.complete();
  }

  isOver(): boolean {
    if (this.url === '/apps/messages' || this.url === '/apps/calendar' || this.url === '/apps/media' || this.url === '/maps/leaflet') {
      return true;
    } else {
      return window.matchMedia(`(max-width: 960px)`).matches;
    }
  }

  isMac(): boolean {
      return (
        (navigator.platform as any).toUpperCase().indexOf('MAC') >= 0
        || (navigator.platform as any).toUpperCase().indexOf('IPAD') >= 0
      );
  }


  menuMouseOver(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && this.collapseSidebar) {
      this.sidemenu.mode = 'over';
    }
  }

  menuMouseOut(): void {
    if (window.matchMedia(`(min-width: 960px)`).matches && this.collapseSidebar) {
      this.sidemenu.mode = 'side';
    }
  }
  
  menuToggleFunc() {
    this.sidemenu.toggle();
    
    if (this.collapsedClass === 'side-panel-opened') {
        this.collapsedClass = 'side-panel-closed';
    } else {
        this.collapsedClass = 'side-panel-opened';
    }
  }

  changeMenuLayout(value) {
    console.log(value);
    if (value) {
      this.menuLayout = 'top-menu';
    } else {
      this.menuLayout = 'vertical-menu';
    }
  }
  
  onSelectSidebarImage(selectedClass, event) {
    this.selectedSidebarImage = selectedClass;
  }
  
  onSelectedSidebarColor(selectedClass) {
    this.selectedSidebarColor = selectedClass;
  }

  addMenuItem(): void {
    this.menuItems.add({
      state: 'menu',
      name: 'MENU',
      type: 'sub',
      icon: 'trending_flat',
      children: [
        {state: 'menu', name: 'MENU'},
        {state: 'timelmenuine', name: 'MENU'}
      ]
    });
  }
}
