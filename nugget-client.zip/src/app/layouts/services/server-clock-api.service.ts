import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import * as moment from 'moment' ;

@Injectable({
  providedIn: 'root'
})
export class ServerClockApiService {

  constructor(private httpClient: HttpClient) { }

  public getTime(): Observable<any> {
    return this.httpClient
      .get(environment.apiUrl + 'common/time', {})
      .map((data) => {
        return moment(data['date']);
      });
  }
}
