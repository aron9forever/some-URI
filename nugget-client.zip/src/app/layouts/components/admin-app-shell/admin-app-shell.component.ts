import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-app-shell',
  templateUrl: './admin-app-shell.component.html',
  styleUrls: ['./admin-app-shell.component.scss']
})
export class AdminAppShellComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
