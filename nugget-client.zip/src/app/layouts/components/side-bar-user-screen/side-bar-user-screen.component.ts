import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {UserMeModel} from '../../../modules/Auth/models/user-me.model';

@Component({
  selector: 'app-side-bar-user-screen',
  templateUrl: './side-bar-user-screen.component.html',
  styleUrls: ['./side-bar-user-screen.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SideBarUserScreenComponent implements OnInit {
  @Input('user') user;
  constructor() { }

  ngOnInit() {
  }

}
