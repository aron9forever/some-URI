import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SideBarUserScreenComponent } from './side-bar-user-screen.component';

describe('SideBarUserScreenComponent', () => {
  let component: SideBarUserScreenComponent;
  let fixture: ComponentFixture<SideBarUserScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SideBarUserScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SideBarUserScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
