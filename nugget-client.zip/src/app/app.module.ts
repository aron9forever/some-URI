import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { JwtModule, JWT_OPTIONS } from '@auth0/angular-jwt';
import {HttpClientModule, HttpClient, HTTP_INTERCEPTORS} from '@angular/common/http';

import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {TranslateService} from '@ngx-translate/core';
import { FlexLayoutModule } from '@angular/flex-layout';

import {MatSidenavModule} from '@angular/material/sidenav';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import {MatMenuModule} from '@angular/material/menu';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTabsModule} from '@angular/material/tabs';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatSelectModule} from '@angular/material/select';
import {MatCardModule} from '@angular/material/card';

import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';

import { AppRoutes } from './app.routing';
import { AppComponent } from './app.component';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { SharedModule } from './modules/Common/shared.module';
import {AuthGuard} from './session/auth.guard';
import { HeaderNavBarComponent } from './layouts/components/header-nav-bar/header-nav-bar.component';
import { AdminAppShellComponent } from './layouts/components/admin-app-shell/admin-app-shell.component';

import { SideBarUserScreenComponent } from './layouts/components/side-bar-user-screen/side-bar-user-screen.component';
import {NoAuthGuard} from './session/no-auth.guard';
import { LoadingBarModule } from '@ngx-loading-bar/core';
import { ClipboardModule } from 'ngx-clipboard';
import {AdminGuard} from './session/admin.guard';
import {ErrorModule} from './modules/Error/error.module';
import {SessionExpiredInterceptor} from './modules/Auth/session-expired.interceptor';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material';
import {MAT_MOMENT_DATE_FORMATS, MatMomentDateModule, MomentDateAdapter} from '@angular/material-moment-adapter';


export function HttpLoaderFactory(http: HttpClient) {
    return new TranslateHttpLoader(http);
}

export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

export function jwtOptionsFactory() {
  return {
    tokenGetter: () => {
      return localStorage.getItem('access_token');
    },
    whitelistedDomains: ['localhost', 'localhost:8000', 'nugget.test']
  }
}

@NgModule({
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    HeaderNavBarComponent,
    AdminAppShellComponent,
    SideBarUserScreenComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    SharedModule,
    RouterModule.forRoot(AppRoutes, {
      scrollPositionRestoration: 'enabled'
    }),
    FormsModule,
    MatSidenavModule,
    MatInputModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    MatToolbarModule,
    MatTabsModule,
    MatCheckboxModule,
    MatProgressBarModule,
    MatSelectModule,
    MatCardModule,
    HttpClientModule,
    FlexLayoutModule,
    ErrorModule,
    SweetAlert2Module.forRoot({
      heightAuto: false,
    }),
    LoadingBarModule,
    ClipboardModule,
    JwtModule.forRoot({
      jwtOptionsProvider: {
        provide: JWT_OPTIONS,
        useFactory: (jwtOptionsFactory)
      }
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
  ],
  providers: [
    AuthGuard,
    NoAuthGuard,
    AdminGuard,
    TranslateService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SessionExpiredInterceptor,
      multi: true
    },
    {provide: MAT_DATE_LOCALE, useValue: 'en'},
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],
  exports: [
  ],
  entryComponents: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
