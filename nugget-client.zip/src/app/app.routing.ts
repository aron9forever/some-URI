import { Routes } from '@angular/router';

import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import {AuthGuard} from './session/auth.guard';
import {E404Component} from './modules/Error/pages/e404/e404.component';

export const AppRoutes: Routes = [{
  path: '',
  redirectTo: 'home',
  pathMatch: 'full',
}, {
  path: '',
  component: AdminLayoutComponent,
  children: [
    {
      path: 'home',
      canActivate: [AuthGuard],
      loadChildren: './modules/Dash/dash.module#DashModule'
    },
    {
      path: 'pickup',
      loadChildren: './modules/Pickup/pickup.module#PickupModule'
    },
    {
      path: 'user',
      canActivate: [AuthGuard],
      loadChildren: './modules/User/user.module#UserModule'
    },
    {
      path: 'welcome',
      loadChildren: './modules/Landing/landing.module#LandingModule'
    },
    {
      path: 'auth',
      loadChildren: './modules/Auth/auth.module#AuthModule'
    },
    {
      path: 'error',
      loadChildren: './modules/Error/error.module#ErrorModule'
    }
  ]
}
, {
  path: '**',
  component: E404Component
}];
