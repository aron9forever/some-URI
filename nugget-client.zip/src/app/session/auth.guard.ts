import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthService } from './auth.service';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(public auth: AuthService, public router: Router) {
  }
  canActivate(): boolean {
    const helper = new JwtHelperService();

    if (!this.auth.isLoggedIn()) {
      this.router.navigate(['welcome']);
      return false;
    } else {
      const data = helper.decodeToken(this.auth.getToken());
    }

    return true;
  }
}