import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthService } from './auth.service';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable()
export class VerifyFunnelGuard implements CanActivate {
  constructor(public auth: AuthService, public router: Router) {
  }
  canActivate(): boolean {
    const helper = new JwtHelperService();

    if (this.auth.isLoggedIn()) {
      const data = helper.decodeToken(this.auth.getToken());

      if (data && !data.verified) {
        this.router.navigate(['/auth/verify']);
        return false;
      }
    }

    return true;
  }
}