import {Injectable} from '@angular/core';
import {CanActivate, Router} from '@angular/router';
import {AuthService, RoleTypes} from './auth.service';
import {JwtHelperService} from '@auth0/angular-jwt';

@Injectable()
export class AdminGuard implements CanActivate {
  constructor(public auth: AuthService, public router: Router) {
  }
  canActivate(): boolean {
    const helper = new JwtHelperService();

    if (!this.auth.hasRole(RoleTypes.ADMIN)) {
      this.router.navigate(['error/403']);
      return false;
    } else {
      //constants data = helper.decodeToken(this.auth.getToken());
    }

    return true;
  }
}
