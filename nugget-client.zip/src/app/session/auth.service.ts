import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import 'rxjs/add/operator/map';
import {JwtHelperService} from '@auth0/angular-jwt';
import {BehaviorSubject} from 'rxjs';
import {AuthApiService} from '../modules/Auth/services/auth-api-service.service';

export enum RoleTypes {
  ADMIN = "ADMIN",
  WORKER = "WORKER",
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private _authStateChangedStream = new BehaviorSubject<any>(true);
  public authStateChangedStream = this._authStateChangedStream.asObservable();
  private token;
  private is_expired = true;
  private token_data;
  private user_roles: string[] = [];
  private user_id: number = 0;
  private user_name: string;

  constructor(
    public jwtHelper: JwtHelperService,
    private authApi: AuthApiService,
  ) {
    this.setToken(localStorage.getItem('access_token'));
  }

  public isLoggedIn() {
      return !this.is_expired;
  }

  get tokenData() {
    return this.token_data;
  }

  get userId() {
    return this.user_id;
  }

  get username() {
    return this.user_name;
  }

  get userRoles() {
    return this.user_roles;
  }

  public hasRole(role: RoleTypes): boolean {
    return (this.user_roles.indexOf(role) > -1);
  }

  public setToken(token): void {
    this.token = token;
    this.user_roles = [];

    if (this.token && !this.jwtHelper.isTokenExpired(this.token)) {
      this.is_expired = false;
      this.token_data = this.jwtHelper.decodeToken(this.token);
      console.log(this.token_data);
      this.user_id = this.token_data.user_id;
      this.user_roles = this.token_data.roles;
      this.user_name = this.token_data.username;

      localStorage.setItem('access_token', token);
    } else {
      this.token_data = undefined;
      this.is_expired = true;
      this.user_id = 0;
      localStorage.removeItem('access_token');
    }

    this.triggerUserDataReload();
  }

  public triggerUserDataReload() {
    this._authStateChangedStream.next(this.token);
  }

  public getToken(): string {
    return this.token;
  };

  public logout(): void {
    this.authApi.postLogout().subscribe();
    this.setToken(false);
  }
}
