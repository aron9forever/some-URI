import { Component, OnInit, OnDestroy } from '@angular/core';
import * as screenfull from 'screenfull';

@Component({
  selector: 'app-welcome-page',
  templateUrl: './welcome-page.component.html',
  styleUrls: ['./welcome-page.component.scss'],
})
export class WelcomePageComponent implements OnInit, OnDestroy {
  timeouts: any[] = [];
  intervals: any[] = [];
  toggledFullScreen = false;
  public isMobileDevice;

  constructor() { }

  ngOnInit() {
    this.isMobileDevice = this._isMobileDevice();
  }

  ngOnDestroy() {
    this.timeouts.forEach(ref => clearTimeout(ref));
    this.intervals.forEach(ref => clearInterval(ref));
  }

  toggleFullScreen() {
    if (!this.toggledFullScreen) {
      this.toggledFullScreen = true;
      if (this.isMobileDevice) {
        alert('fulled');
        screenfull.request();
      }
    }
  }


  private _isMobileDevice(): boolean {
    const matches = ['iphone', 'linux armv', 'aarch64', 'ipad', 'Linux i686', 'ipod', 'Linux MSM8960'];
    const platform = (navigator.platform as any).toUpperCase();
    let result = false;

    matches.forEach( key => {
      result = (platform.indexOf(key.toUpperCase()) >= 0);
    } );

    return result;
  }
}
