import { Routes } from '@angular/router';
import { WelcomePageComponent } from './pages/welcome-page/welcome-page.component';

export const LandingRoutes: Routes = [{
  path: '',
  component: WelcomePageComponent
}];
