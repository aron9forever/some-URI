import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import {LandingRoutes} from './landing.routes';
import {WelcomePageComponent} from './pages/welcome-page/welcome-page.component';
import {SharedModule} from '../Common/shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(LandingRoutes)
  ],
  declarations: [WelcomePageComponent]
})
export class LandingModule { }
