import {Component, OnDestroy, OnInit} from '@angular/core';
import {UserModel} from '../../models/user.model';
import {UserApiService} from '../../services/user-api.service';
import * as moment from 'moment';
import {ContentLoadingOverlayService} from '../../../Common/services/content-loading-overlay/content-loading-overlay.service';
import {MatDialog, MatDialogRef} from '@angular/material';
import {UserCreateStepperComponent} from '../../components/user-create-stepper/user-create-stepper.component';
import {UserEditFormComponent} from '../../components/user-edit-form/user-edit-form.component';

@Component({
  selector: 'app-users-management-page',
  templateUrl: './users-management-page.component.html',
  styleUrls: ['./users-management-page.component.scss']
})
export class UsersManagementPageComponent implements OnInit, OnDestroy {
  readonly componentKey = 'users-management-page';
  private addUserDialogRef: MatDialogRef<any>;
  private stepperUpdateSubscription;
  private stepperUpdateWorkerSubscription;
  private userUpdateSub;

  public users: UserModel[] = [];
  public workers: UserModel[] = [];

  constructor(
    private userApi: UserApiService,
    private loader: ContentLoadingOverlayService,
    public dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.loadUsers();
    this.loadWorkers();
  }

  ngOnDestroy(): void {
    this.loader.signOut(this.componentKey);
  }

  public onSelect(row) {
    console.log(row);
  }

  public addUser () {
    if (this.stepperUpdateSubscription) {
      this.stepperUpdateSubscription.unsubscribe();
    }
    if (this.stepperUpdateWorkerSubscription) {
      this.stepperUpdateWorkerSubscription.unsubscribe();
    }

    this.addUserDialogRef = this.dialog.open(UserCreateStepperComponent, {
      width: '90%',
      height: '80vh',
      data: {}
    });

    this.stepperUpdateSubscription = this.addUserDialogRef.componentInstance.userReload.subscribe( () => {
      this.loadUsers();
    } );

    this.stepperUpdateWorkerSubscription = this.addUserDialogRef.componentInstance.workerReload.subscribe( () => {
      this.loadWorkers();
    } );
  }

  public loadUsers() {
    this.loader.pushLoad(this.componentKey);
    this.userApi.getUsers().subscribe( users => {
      this.users = users;
      this.loader.popLoad(this.componentKey);
    } );
  }

  public loadWorkers() {
    this.loader.pushLoad(this.componentKey);
    this.userApi.getWorkers().subscribe( workers => {
      this.workers = workers;
      this.loader.popLoad(this.componentKey);
    } );
  }

  enableEdit(user) {
    if (this.userUpdateSub) {
      this.userUpdateSub.unsubscribe();
    }

    this.addUserDialogRef = this.dialog.open(UserEditFormComponent, {
      width: '90%',
      height: '80vh',
      data: {user: user}
    });

    this.userUpdateSub = this.addUserDialogRef.componentInstance.userReload.subscribe( (newUser) => {
      if (newUser.worker) {
        this.loadWorkers();
      } else {
        this.loadUsers();
      }
    } );
  }

  isRecent(u: UserModel) {
    return (moment(new Date()).diff(moment(u.created_at), 'days') < 2);
  }
}
