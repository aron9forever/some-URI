import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import {SharedModule} from '../Common/shared.module';
import {UserRoutes} from './user.routes';
import { UserRoleChipComponent } from './components/user-role-chip/user-role-chip.component';
import { UsersManagementPageComponent } from './pages/users-management-page/users-management-page.component';
import { UserCreateStepperComponent } from './components/user-create-stepper/user-create-stepper.component';
import { UserEditFormComponent } from './components/user-edit-form/user-edit-form.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(UserRoutes),
    SharedModule,
  ],
  providers: [
  ],
  declarations: [
    UserRoleChipComponent,
    UsersManagementPageComponent,
    UserCreateStepperComponent,
    UserEditFormComponent
  ],
  entryComponents: [
    UserCreateStepperComponent,
    UserEditFormComponent
  ]
})
export class UserModule { }
