import { Routes } from '@angular/router';
import {UsersManagementPageComponent} from './pages/users-management-page/users-management-page.component';
import {AdminGuard} from '../../session/admin.guard';

export const UserRoutes: Routes = [
  {
    path: 'manage',
    component: UsersManagementPageComponent,
    canActivate: [AdminGuard]
  },
];
