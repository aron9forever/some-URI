import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../../../../environments/environment';
import {UserModel} from '../models/user.model';
import {UserMeModel} from '../../Auth/models/user-me.model';

@Injectable({
  providedIn: 'root'
})
export class UserApiService {

  constructor(private httpClient: HttpClient) { }

  public getUser(id: number): Observable<UserModel> {
    return this.httpClient
      .get<UserModel>(environment.apiUrl + 'auth/users/' + id, {})
      .map((data) => {
        return UserModel.fromJson(data);
      });
  }

  public getUsers(): Observable<UserModel[]> {
    return this.httpClient
      .get<UserModel[]>(environment.apiUrl + 'auth/users', {})
      .map((results) => {
        results.forEach( (serverData, index, array) => {
          array[index] = UserModel.fromJson(serverData);
        } );

        return results;
      });
  }

  public getWorkers(): Observable<UserModel[]> {
    return this.httpClient
      .get<UserModel[]>(environment.apiUrl + 'auth/users/workers', {})
      .map((results) => {
        results.forEach( (serverData, index, array) => {
          array[index] = UserModel.fromJson(serverData);
        } );

        return results;
      });
  }

  public postUser(data) {
    return this.httpClient.post(environment.apiUrl + 'auth/users', data)
      .map((result) => {
        return UserModel.fromJson(result);
      });
  }

  public postWorker(data) {
    return this.httpClient.post(environment.apiUrl + 'auth/users/worker', data)
      .map((result) => {
        return UserModel.fromJson(result);
      });
  }

  public patchUser(id, data) {
    return this.httpClient.patch(environment.apiUrl + 'auth/users/' + id, data)
      .map((result) => {
        return UserMeModel.fromJson(result);
      });
  }

  public deleteUser(id, data) {
    return this.httpClient.delete(environment.apiUrl + 'auth/users/' + id, data);
  }
}
