export class WorkerModel {
  id: number;
  user_id: number;
  access_key: string;
  created_at: string;
  updated_at: string;
  deleted_at: string;

  static fromJson(data) {
    const obj = Object.assign(new WorkerModel, data);
    return obj;
  }
}