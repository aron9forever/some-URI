import {WorkerModel} from './worker.model';

export class UserModel {
  id: number;
  nickname: string;
  email: string;
  created_at: string;
  updated_at: string;
  worker: WorkerModel;

  static fromJson(data) {
    const obj = Object.assign(new UserModel, data);

    if(data['worker']) {
      obj.worker = WorkerModel.fromJson(data['worker']);
    }

    return obj;
  }
}