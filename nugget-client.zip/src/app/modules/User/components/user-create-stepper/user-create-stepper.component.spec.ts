import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCreateStepperComponent } from './user-create-stepper.component';

describe('UserCreateStepperComponent', () => {
  let component: UserCreateStepperComponent;
  let fixture: ComponentFixture<UserCreateStepperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserCreateStepperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCreateStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
