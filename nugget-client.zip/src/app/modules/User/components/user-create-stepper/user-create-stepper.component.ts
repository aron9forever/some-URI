import {Component, EventEmitter, Inject, OnDestroy, OnInit, Output, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ContentLoadingOverlayService} from '../../../Common/services/content-loading-overlay/content-loading-overlay.service';
import {UserApiService} from '../../services/user-api.service';
import {UserModel} from '../../models/user.model';
import {SwalPopupsService} from '../../../Common/services/swal-popups/swal-popups.service';

enum CLASSES {
 ADMIN = 'admin',
 WORKER = 'worker',
}

@Component({
  selector: 'app-user-create-stepper',
  templateUrl: './user-create-stepper.component.html',
  styleUrls: ['./user-create-stepper.component.scss']
})
export class UserCreateStepperComponent implements OnInit, OnDestroy {
  @ViewChild('adminStepper') adminStepper;
  @ViewChild('workerStepper') workerStepper;
  @Output('userReload') userReload = new EventEmitter<any>();
  @Output('workerReload') workerReload = new EventEmitter<any>();
  readonly componentKey = 'users-create-stepper';
  CLASSES = CLASSES;
  processStarted = false;
  creatingClass = '';
  public newUser = UserModel;

  adminForm = this._formBuilder.group({
    email: ['', [Validators.required, Validators.email]],
    nickname: ['', [Validators.required, Validators.minLength(2)]],
    password: ['', [Validators.required, Validators.minLength(10)]],
  });

  workerForm = this._formBuilder.group({
    email: ['', [Validators.required, Validators.email]],
    nickname: ['', [Validators.required, Validators.minLength(2)]],
    access_key: ['', [Validators.required, Validators.minLength(4)]],
  });

  constructor(
    public dialogRef: MatDialogRef<UserCreateStepperComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private _formBuilder: FormBuilder,
    private loader: ContentLoadingOverlayService,
    private userApi: UserApiService,
    public swal: SwalPopupsService,
  ) { }

  ngOnInit() {
    this.dialogRef.afterClosed().subscribe(
      () => {
        this.processStarted = false;
      }
    );
  }

  ngOnDestroy(): void {
    this.loader.signOut(this.componentKey);
  }

  makeWorker() {
    this.processStarted = true;
    this.creatingClass = CLASSES.WORKER;
  }

  makeAdmin() {
    this.processStarted = true;
    this.creatingClass = CLASSES.ADMIN;
  }

  submitAdmin() {
    this.loader.pushLoad(this.componentKey);

    this.userApi.postUser(this.adminForm.value)
      .subscribe( user => {
        this.newUser = user;
        this.adminStepper.selected.completed = true;
        this.adminStepper.next();
        this.loader.popLoad(this.componentKey);
        this.userReload.next(true);
      }, error => {
        SwalPopupsService.laravelErrorResponseSwal(error);
        this.loader.popLoad(this.componentKey);
      } );
  }

  submitWorker() {
    this.loader.pushLoad(this.componentKey);

    this.userApi.postWorker(this.workerForm.value)
      .subscribe( user => {
        this.newUser = user;
        this.workerStepper.selected.completed = true;
        this.workerStepper.next();
        this.loader.popLoad(this.componentKey);
        this.workerReload.next(true);
      }, error => {
        SwalPopupsService.laravelErrorResponseSwal(error);
        this.loader.popLoad(this.componentKey);
      } );
  }

  hasRequiredError(form, key: string) {
    return (form.controls[key].hasError('required') &&
      (form.controls[key].touched || form.controls[key].dirty));
  }

  //dummy
  dontClose() {

  }

  close() {
    this.dialogRef.close();
  }

  markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
