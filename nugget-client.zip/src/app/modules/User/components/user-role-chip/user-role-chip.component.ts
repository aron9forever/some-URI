import { Component, OnInit, Input } from '@angular/core';
import {UserMeModel} from '../../../Auth/models/user-me.model';

export const USER_ROLES = [

];

@Component({
  selector: 'app-user-role-chip',
  templateUrl: './user-role-chip.component.html',
  styleUrls: ['./user-role-chip.component.scss']
})
export class UserRoleChipComponent implements OnInit {
  public _user: UserMeModel;
  public topRole: string;

  @Input()
  set name(user: UserMeModel) {
    this._user = user;

    user.roles.forEach( role => {

    } )
  }

  constructor() { }

  ngOnInit() {
  }

}
