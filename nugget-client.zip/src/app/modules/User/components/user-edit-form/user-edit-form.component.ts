import {Component, EventEmitter, Inject, OnDestroy, OnInit, Output} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {UserApiService} from '../../services/user-api.service';
import Swal from "sweetalert2";
import {SwalPopupsService} from '../../../Common/services/swal-popups/swal-popups.service';
import {ContentLoadingOverlayService} from '../../../Common/services/content-loading-overlay/content-loading-overlay.service';
import {LanguageBookService} from '../../../Common/services/language-book/language-book.service';
import {AuthService} from '../../../../session/auth.service';

@Component({
  selector: 'app-user-edit-form',
  templateUrl: './user-edit-form.component.html',
  styleUrls: ['./user-edit-form.component.scss']
})
export class UserEditFormComponent implements OnInit, OnDestroy {
  @Output('userReload') userReload = new EventEmitter<any>();
  public userForm: FormGroup;
  readonly componentKey = 'users-edit-form';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
    private _formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<UserEditFormComponent>,
    private userApi: UserApiService,
    private loader: ContentLoadingOverlayService,
    private lang: LanguageBookService,
    public swal: SwalPopupsService,
    public authService: AuthService
  ) { }

  ngOnInit() {
    if (this.isWorker) {
      this.userForm = this._formBuilder.group({
        email: ['', [Validators.required, Validators.email]],
        nickname: ['', [Validators.required, Validators.minLength(2)]],
        access_key: ['', [Validators.required, Validators.minLength(4)]],
      });
    } else {
      this.userForm = this._formBuilder.group({
        email: ['', [Validators.required, Validators.email]],
        nickname: ['', [Validators.required, Validators.minLength(2)]],
        password: ['', [Validators.minLength(10)]],
      });
    }

    if (this.isWorker) {
      this.data.user.access_key = this.data.user.worker.access_key;
    }
    this.userForm.patchValue(this.data.user);
  }

  ngOnDestroy(): void {
    this.loader.signOut(this.componentKey);
  }

  get isWorker() {
    return typeof this.data.user.worker !== 'undefined';
  }

  saveChanges() {
    if (this.userForm.valid) {
      let newData;
      if(this.userForm.value.password !== '') {
        newData = this.userForm.value;
      } else {
        newData = this.userForm.value;
        delete newData['password'];
      }

      this.loader.pushLoad(this.componentKey);
      this.userApi.patchUser(this.data.user.id, newData)
        .subscribe( user => {
            this.loader.popLoad(this.componentKey);
            Swal({
              title: this.lang.book.USER_MANAGER.USER_UPDATED.TITLE,
              text: this.lang.book.USER_MANAGER.USER_UPDATED.BODY,
              type: 'info',
              confirmButtonText: this.lang.book.BUTTONS.CLOSE,
              heightAuto: false,
            }).then(result => {
              this.close();
              this.userReload.next(user);

              if (user.id === this.authService.userId) {
                this.authService.triggerUserDataReload();
              }
            });
        }, error => {
          this.loader.popLoad(this.componentKey);
          SwalPopupsService.laravelErrorResponseSwal(error);
        });
    }
  }

  close() {
    this.dialogRef.close();
  }

  hasRequiredError(form, key: string) {
    return (form.controls[key].hasError('required') &&
      (form.controls[key].touched || form.controls[key].dirty));
  }

  /**
   * Marks all controls in a form group as touched
   * @param formGroup - The group to caress..hah
   */
  public markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
