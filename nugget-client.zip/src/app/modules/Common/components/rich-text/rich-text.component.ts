import {ChangeDetectionStrategy, Component, Input, OnInit} from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-rich-text',
  templateUrl: './rich-text.component.html',
  styleUrls: ['./rich-text.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RichTextComponent implements OnInit {
  @Input('content') content;

  public quillModules = {
    toolbar: false,
  };

  constructor(public sanitizer: DomSanitizer) { }

  ngOnInit() {
  }

}
