import {Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'app-simple-data-card',
  templateUrl: './simple-data-card.component.html',
  styleUrls: ['./simple-data-card.component.scss']
})
export class SimpleDataCardComponent implements OnInit {
  @Input('label') label;
  @Input('value') value;
  @Input('height') height;

  constructor() { }

  ngOnInit() {
  }

}
