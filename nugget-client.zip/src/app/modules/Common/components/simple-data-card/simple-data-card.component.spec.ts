import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimpleDataCardComponent } from './simple-data-card.component';

describe('SimpleDataCardComponent', () => {
  let component: SimpleDataCardComponent;
  let fixture: ComponentFixture<SimpleDataCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimpleDataCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimpleDataCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
