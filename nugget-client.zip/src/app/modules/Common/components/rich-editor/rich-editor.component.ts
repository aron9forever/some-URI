import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

import * as QuillNamespace from 'quill';
let Quill: any = QuillNamespace;
import QuillEmoji from 'quill-emoji/dist/quill-emoji';
import MagicUrl from 'quill-magic-url';
Quill.register('modules/emoji', QuillEmoji);
Quill.register('modules/magicUrl', MagicUrl);

@Component({
  selector: 'app-rich-editor',
  templateUrl: './rich-editor.component.html',
  styleUrls: ['./rich-editor.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RichEditorComponent implements OnInit {
  @Input() content = '';
  @Output() contentChange = new EventEmitter<string>();

  public quillModules = {
    history: {
      maxStack: 500
    },
    toolbar: {
      container: [
        ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
        ['blockquote', 'code-block'],
        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
        [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
        //[{ 'direction': 'rtl' }],                         // text direction
        [{ 'header': [1, 2, 3, 4, 5, 6, false] }],

        [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
        [{ 'align': [] }],

        ['clean'],                                         // remove formatting button

        ['link', 'video'],                         // link and image, video

        ['emoji'],
      ],
      handlers: {'emoji': function() {}}
    },
    "emoji-shortname": true,
    magicUrl: true,
  };

  constructor() { }

  ngOnInit() {
  }

  contentChanged($event) {
    console.log($event);
    //this.content = $event;
    this.contentChange.emit($event);
  }

}
