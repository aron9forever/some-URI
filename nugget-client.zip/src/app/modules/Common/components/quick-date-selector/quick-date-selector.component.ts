import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import * as moment from 'moment';
import {Moment} from 'moment';

export type QuickDateSelectStepTypes = 'day' | 'week';

@Component({
  selector: 'app-quick-date-selector',
  templateUrl: './quick-date-selector.component.html',
  styleUrls: ['./quick-date-selector.component.scss']
})
export class QuickDateSelectorComponent implements OnInit, OnChanges {
  readonly today = moment(new Date());
  @Input() stepSize: QuickDateSelectStepTypes = 'day';
  @Input() startingDate: Moment = moment(this.today);
  public weekEndDay: Moment = moment(this.today).add('6', 'days');
  @Output() startingDateChange = new EventEmitter();
  constructor(
  ) { }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.weekEndDay = moment(this.startingDate).add('6', 'days');
  }

  get stepSizes(): "weeks" | "days" {
    return this.stepSize.concat('s') as "weeks" | "days";
  }

  subDay() {
    this.setDay(
      moment(this.startingDate.subtract(1, this.stepSizes))
    )
  }

  addDay() {
    this.setDay(
      moment(this.startingDate.add(1, this.stepSizes))
    )
  }

  private setDay(day: Moment) {
    this.startingDate = day;
    this.weekEndDay = moment(day).add(6, 'days');
    this.startingDateChange.next(this.startingDate);
  }

  public reset() {
    this.setDay(moment(this.today));
  }
}
