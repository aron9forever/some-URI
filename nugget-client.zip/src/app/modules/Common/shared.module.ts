import { NgModule } from '@angular/core';

import { MenuItems } from './menu-items/menu-items';
import { HorizontalMenuItems } from './menu-items/horizontal-menu-items';
import { AccordionAnchorDirective, AccordionLinkDirective, AccordionDirective } from './accordion/index';
import { ToggleFullscreenDirective } from './fullscreen/toggle-fullscreen.directive';
import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';
import {
  MatButtonModule,
  MatFormFieldModule,
  MatInputModule,
  MatCardModule,
  MatTabsModule, MatIconModule, MatDialogModule, MatStepperModule, MatRadioModule, MatSelectModule, MatDatepickerModule, MatCheckboxModule,
} from '@angular/material';
import {MatChipsModule} from '@angular/material/chips';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RecaptchaModule} from 'ng-recaptcha';
import {RecaptchaFormsModule} from 'ng-recaptcha/forms';
import { MomentModule } from 'angular2-moment';
import { RichTextComponent } from './components/rich-text/rich-text.component';
import { RichEditorComponent } from './components/rich-editor/rich-editor.component';
import {QuillModule} from 'ngx-quill';
import { NgScrollbarModule } from 'ngx-scrollbar';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import { OwlDateTimeModule } from 'ng-pick-datetime';
import { OwlMomentDateTimeModule } from 'ng-pick-datetime-moment';
import { SimpleDataCardComponent } from './components/simple-data-card/simple-data-card.component';
import {TranslateModule} from '@ngx-translate/core';
import { QuickDateSelectorComponent } from './components/quick-date-selector/quick-date-selector.component';
import {CommonModule} from '@angular/common';



@NgModule({
    imports: [
      CommonModule,
      SweetAlert2Module,
      RecaptchaModule.forRoot(),
      RecaptchaFormsModule,
      MomentModule,
      QuillModule,
      FormsModule,
      MatIconModule,
      MatButtonModule,
      MatDatepickerModule,
      OwlDateTimeModule,
      OwlMomentDateTimeModule,
      TranslateModule,
    ],
  declarations: [
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,
    RichTextComponent,
    RichEditorComponent,
    SimpleDataCardComponent,
    QuickDateSelectorComponent,
  ],
  exports: [
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,
    SweetAlert2Module,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatRadioModule,
    MatChipsModule,
    MatCardModule,
    MatTabsModule,
    MatIconModule,
    MatStepperModule,
    MatSelectModule,
    MatCheckboxModule,
    MatDatepickerModule,
    ReactiveFormsModule,
    RecaptchaModule,
    RecaptchaFormsModule,
    MomentModule,
    FormsModule,
    RichTextComponent,
    QuillModule,
    RichEditorComponent,
    MatDialogModule,
    NgScrollbarModule,
    NgxDatatableModule,
    OwlDateTimeModule,
    OwlMomentDateTimeModule,
    SimpleDataCardComponent,
    TranslateModule,
    QuickDateSelectorComponent,
  ],
  providers: [ MenuItems, HorizontalMenuItems ]
})
export class SharedModule { }
