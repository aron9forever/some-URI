import {HttpErrorResponse, HttpParams} from '@angular/common/http';

export class HttpUtil {
  /**
   * Transforms the HttpTurd into a somewhat readable format.
   * @param {HttpErrorResponse} error
   * @returns {string}
   */
  static laravelValidationErrorToString(error: HttpErrorResponse): string {
    let errMsg = '';

    //          [GOD] Has left the server
    if (error && error.error && error.error.errors) {
      errMsg += error.error.message + ' ';

      for (const err in error.error.errors) {
        if(typeof error.error.errors[err][0] === 'string') {
          errMsg += error.error.errors[err][0] + ' ';
        }
      }
    } else {
      errMsg = 'Operation failed, please check your input and try again.';
    }

    return errMsg;
  }

  static objectToHttpParam(obj): HttpParams {
    let params: HttpParams = new HttpParams();

    Object.entries(obj).forEach(([key, val]) => {
      if (val) {
        params = params.set(key, val as string);
      }
    });

    return params;
  }
}
