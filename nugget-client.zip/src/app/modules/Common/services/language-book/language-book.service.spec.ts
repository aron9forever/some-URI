import { TestBed } from '@angular/core/testing';

import { LanguageBookService } from './language-book.service';

describe('LanguageBookService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LanguageBookService = TestBed.get(LanguageBookService);
    expect(service).toBeTruthy();
  });
});
