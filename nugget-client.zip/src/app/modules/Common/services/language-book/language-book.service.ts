import {EventEmitter, Injectable} from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {DateAdapter} from '@angular/material';
import {DateTimeAdapter} from 'ng-pick-datetime';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class LanguageBookService {
  private readonly storageKey = 'chosen_lang';
  public static readonly availableLanguages = ['en', 'ro', 'cs'];
  public languageChanged = new EventEmitter();
  private _chosenLanguage;
  private _lang;
  private langBookSub;

  get book() {
    return this._lang;
  }

  get currrentLang() {
    return this._chosenLanguage;
  }

  constructor(
    public translate: TranslateService,
    private dateAdapter: DateAdapter<any>,
    private dateTimeAdapter: DateTimeAdapter<any>,
    ) {
    translate.addLangs(LanguageBookService.availableLanguages);
    translate.setDefaultLang(LanguageBookService.availableLanguages[0]);

    const browserLang: string = translate.getBrowserLang();
    const savedLang = localStorage.getItem(this.storageKey);
    if (savedLang) {
      this.setLang(savedLang);
    } else {
      this.setLang(LanguageBookService.availableLanguages.indexOf(browserLang) !== -1 ? browserLang : 'en');
    }
  }

  private initLangSubscription() {
    if (this.langBookSub) {
      this.langBookSub.unsubscribe();
    }

    this.langBookSub = this.translate.get('LANG', {})
      .subscribe((res) => {
        this._lang = res;
      });
  }

  public setLang(lang) {
    if (LanguageBookService.availableLanguages.indexOf(lang) !== -1) {
      console.log(lang);
      this._chosenLanguage = lang;
      this.translate.use(lang);
      localStorage.setItem(this.storageKey, lang);
      this.dateAdapter.setLocale(lang);
      this.dateTimeAdapter.setLocale(lang);
      moment.locale(lang);
      this.initLangSubscription();
      this.languageChanged.emit(lang);
    } else {
      console.error('Invalid language chosen!');
    }
  }
}
