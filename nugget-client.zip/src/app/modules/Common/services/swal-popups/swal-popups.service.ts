import { Injectable } from '@angular/core';
import Swal from "sweetalert2";
import {HttpUtil} from '../../utils/http.util';
import {LanguageBookService} from '../language-book/language-book.service';

@Injectable({
  providedIn: 'root'
})
export class SwalPopupsService {
  private GLOBAL_SWAL_SETTINGS;

  constructor(
    private lang: LanguageBookService,
  ) {
    this.loadFreshLang();
    this.lang.languageChanged.subscribe( e => {
      this.loadFreshLang();
    } );
  }

  get swalGlobalConfig() {
    return this.GLOBAL_SWAL_SETTINGS;
  }

  public loadFreshLang() {
    this.GLOBAL_SWAL_SETTINGS = {
      cancelButtonText: this.lang.book.BUTTONS.CANCEL,
      confirmButtonText: this.lang.book.BUTTONS.CONFIRM,
      heightAuto: false,
    };
  }

  public confirmClose(callback, cancelCallback = () => {}) {
    Swal(
      Object.assign({}, this.GLOBAL_SWAL_SETTINGS, {
        title: this.lang.book.FORM.CONFIRM_CANCEL.TITLE,
        text: this.lang.book.FORM.CONFIRM_CANCEL.BODY,
        type: 'question',
        focusCancel: true,
        showCancelButton: true,
      })
    ).then((result) => {
      if (result.value) {
        callback();
      } else if (
        result.dismiss === Swal.DismissReason.cancel
      ) {
        cancelCallback();
      }
    });
  }

  /*
    deprecated
   */
  static laravelErrorResponseSwal(error) {
    Swal({
      title: 'Something went wrong!',
      text: HttpUtil.laravelValidationErrorToString(error),
      type: 'warning',
      confirmButtonText: 'continue',
      heightAuto: false,
    }).then(Swal.noop);
  }

}
