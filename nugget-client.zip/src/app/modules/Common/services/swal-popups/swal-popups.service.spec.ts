import { TestBed } from '@angular/core/testing';

import { SwalPopupsService } from './swal-popups.service';

describe('SwalPopupsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SwalPopupsService = TestBed.get(SwalPopupsService);
    expect(service).toBeTruthy();
  });
});
