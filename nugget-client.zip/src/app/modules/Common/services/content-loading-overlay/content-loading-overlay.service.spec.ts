import { TestBed } from '@angular/core/testing';

import { ContentLoadingOverlayService } from './content-loading-overlay.service';

describe('ContentLoadingOverlayService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContentLoadingOverlayService = TestBed.get(ContentLoadingOverlayService);
    expect(service).toBeTruthy();
  });
});
