import { Injectable } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';

@Injectable({
  providedIn: 'root'
})
export class ContentLoadingOverlayService {
  private loads = [];
  public is_loading_early = false;
  public is_loading = false;

  constructor(private loadingBar: LoadingBarService) { }

  public pushLoad(key: string) {
    this.loads.push(key);

    if (!this.is_loading_early) {
      this.is_loading_early = true;

      setTimeout(() => {
        if (this.is_loading_early) {
          this.is_loading = true;
          this.loadingBar.start();
        }
      }, 500);
    }
  }

  public popLoad(key: string) {
    const i = this.loads.indexOf(key);
    if (i > -1) {
      this.loads.splice(i, 1);
    }

    if (!this.loads.length) {
      setTimeout(() => {
        this.is_loading_early = false;
        this.is_loading = false;
        this.loadingBar.complete();
      });
    }
  }

  public signOut(key: string) {
    while (this.loads.indexOf(key) > -1) {
      this.popLoad(key);
    }
  }
}
