import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import {OverlayContainer} from '@angular/cdk/overlay';

@Injectable({
  providedIn: 'root'
})
export class AppSettingsService {
  private _volumeOptionStream = new BehaviorSubject<boolean>(true);
  public volumeOptionStream = this._volumeOptionStream.asObservable();
  private _darkModeOptionStream = new BehaviorSubject<boolean>(true);
  public darkModeOptionStream = this._darkModeOptionStream.asObservable();
  private volume_enabled: boolean;
  private dark_mode_enabled: boolean;
  private overlay;
  private renderer: Renderer2;

  constructor(
    private overlayContainer: OverlayContainer,
    rendererFactory: RendererFactory2
  ) {
    this.renderer = rendererFactory.createRenderer(null, null);
    this.overlay = overlayContainer.getContainerElement();
    this.volume_enabled = (localStorage.getItem('setting_volume_enabled') === 'true');
    this.dark_mode_enabled = (localStorage.getItem('setting_dark_mode_enabled') === 'true');
    this.appDarkStateChanged();
  }

  get isVolumeEnabled() {
    return this.volume_enabled;
  }

  get isDarkModeEnabled() {
    return this.dark_mode_enabled;
  }

  get darkModeAccessor() {
    return this.dark_mode_enabled;
  }

  set darkModeAccessor(value) {
    this.dark_mode_enabled = value;
    this.appDarkStateChanged();
  }

  public toggleVolume(): void {
    this.volume_enabled = !this.volume_enabled;
    localStorage.setItem('setting_volume_enabled', this.volume_enabled ? 'true' : 'false');
    this._volumeOptionStream.next(this.volume_enabled);
  }

  public toggleDarkMode(): void {
    this.dark_mode_enabled = !this.dark_mode_enabled;
  }

  private appDarkStateChanged() {
    localStorage.setItem('setting_dark_mode_enabled', this.dark_mode_enabled ? 'true' : 'false');
    this._darkModeOptionStream.next(this.dark_mode_enabled);

    if (this.dark_mode_enabled) {
      this.renderer.addClass(document.body, 'app-dark');
      this.overlay.classList.add('app-dark');
    } else {
      this.overlay.classList.remove('app-dark');
      this.renderer.removeClass(document.body, 'app-dark');
    }
  }
}
