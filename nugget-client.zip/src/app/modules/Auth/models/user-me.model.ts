export class UserMeModel {
  id: number;
  nickname: string;
  bio: string;
  email: string;
  verified: boolean;
  has_avatar: boolean;
  avatar_link: string;
  created_at: string;
  updated_at: string;
  roles: any;

  static fromJson(data) {
    return Object.assign(new UserMeModel, data);
  }
}