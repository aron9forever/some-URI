import {AbstractControl} from '@angular/forms';

export class PasswordConfirmationValidator {

  static PasswordsMatch(formGroup: AbstractControl) {
    if (formGroup.get('password').value !== formGroup.get('password_confirmation').value) {
      formGroup.get('password_confirmation').setErrors( {NoMatch: true} );
    } else {
      return null;
    }
  }
}
