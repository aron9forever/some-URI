import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import {AuthRoutes} from './auth.routes';
import {SharedModule} from '../Common/shared.module';
import {AuthApiService} from './services/auth-api-service.service';
import { LoginFormPageComponent } from './pages/login/login-form-page/login-form-page.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AuthRoutes),
    SharedModule
  ],
  providers: [
    AuthApiService
  ],
  declarations: [
    LoginFormPageComponent,
  ]
})
export class AuthModule { }
