import { Injectable } from '@angular/core';
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import {AuthService} from '../../session/auth.service';
import {Router} from '@angular/router';
import Swal from "sweetalert2";
import {LanguageBookService} from '../Common/services/language-book/language-book.service';

@Injectable({providedIn: 'root'})
export class SessionExpiredInterceptor implements HttpInterceptor {
  constructor(
    private authService: AuthService,
    private router: Router,
    private lang: LanguageBookService,
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // console.info('req.headers =', req.headers, ';');
    return next.handle(req)
      .map((event: HttpEvent<any>) => {
        // if (event instanceof HttpResponse && ~~(event.status / 100) > 3) {
        //   console.info('HttpResponse::event =', event, ';');
        // } else console.info('event =', event, ';');
        return event;
      })
      .catch((err: any, caught) => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 401 && this.authService.isLoggedIn()) {
            Swal({
              title: this.lang.book.ERROR.TOKEN_EXPIRED.TITLE,
              text: this.lang.book.ERROR.TOKEN_EXPIRED.BODY,
              type: 'warning',
              confirmButtonText: this.lang.book.BUTTONS.OK,
              heightAuto: false,
            }).then(() => {
              this.authService.logout();
              this.router.navigate(['/welcome']);
            });
          }
          return throwError(err);
        }
      });
  }
}
