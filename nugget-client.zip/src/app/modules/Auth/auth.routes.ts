import { Routes } from '@angular/router';
import {NoAuthGuard} from '../../session/no-auth.guard';
import {LoginFormPageComponent} from './pages/login/login-form-page/login-form-page.component';

export const AuthRoutes: Routes = [
  {
    path: 'login',
    component: LoginFormPageComponent,
    canActivate: [NoAuthGuard],
  }
];
