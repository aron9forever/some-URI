import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AuthApiService} from '../../../services/auth-api-service.service';
import {Router} from '@angular/router';
import {AuthService} from '../../../../../session/auth.service';
import Swal from 'sweetalert2';
import {AppSettingsService} from '../../../../Common/services/app-settings/app-settings.service';
import {LanguageBookService} from '../../../../Common/services/language-book/language-book.service';

@Component({
  selector: 'app-login-form-page',
  templateUrl: './login-form-page.component.html',
  styleUrls: ['./login-form-page.component.scss']
})
export class LoginFormPageComponent implements OnInit {
  @ViewChild('captchaRef') captchaRef;

  loginForm = this.fb.group({
    username: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(4)]],
    //recaptcha: ['', [Validators.required]],
  });

  constructor(
    private fb: FormBuilder,
    private authApiService: AuthApiService,
    private router: Router,
    private authService: AuthService,
    public settingsService: AppSettingsService,
    private lang: LanguageBookService
  ) {
  }

  ngOnInit() {
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.authApiService.postLogin(this.loginForm.value).subscribe(
        data => {
          Swal({
            title: this.lang.book.AUTH.ALERTS.LOGIN.TITLE,
            text: this.lang.book.AUTH.ALERTS.LOGIN.BODY,
            type: 'info',
            confirmButtonText: this.lang.book.BUTTONS.CONTINUE,
            heightAuto: false,
          }).then(result => {
            this.authService.setToken(data['token']);
            this.router.navigate(['/']);
          });
        },
        error => {
          Swal({
            title: this.lang.book.AUTH.ALERTS.WRONG_CREDENTIALS.TITLE,
            text: this.lang.book.AUTH.ALERTS.WRONG_CREDENTIALS.BODY,
            type: 'warning',
            confirmButtonText: this.lang.book.BUTTONS.CONTINUE,
            heightAuto: false,
          }).then(() => {
            //this.captchaRef.reset();
          });
        }
      );
    } else {
      this.markFormGroupTouched(this.loginForm);
    }
  }

  hasRequiredError(key: string) {
    return (this.loginForm.controls[key].hasError('required') &&
      (this.loginForm.controls[key].touched || this.loginForm.controls[key].dirty));
  }

  /**
   * Marks all controls in a form group as touched
   * @param formGroup - The group to caress..hah
   */
  private markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }

}
