import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../../environments/environment';
import {UserMeModel} from '../models/user-me.model';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthApiService {

  constructor(private httpClient: HttpClient) { }

  public postRegister(data) {
    return this.httpClient.post(environment.apiUrl + 'auth/register', data);
  }

  public postLogin(data) {
    return this.httpClient.post(environment.apiUrl + 'login_check', data);
  }

  public postLogout() {
    return this.httpClient.post(environment.apiUrl + 'auth/logout', []);
  }

  public postMe(): Observable<UserMeModel> {
    return this.httpClient
      .post<UserMeModel>(environment.apiUrl + 'auth/me', {})
      .map((result: UserMeModel) => UserMeModel.fromJson(result));
  }
}
