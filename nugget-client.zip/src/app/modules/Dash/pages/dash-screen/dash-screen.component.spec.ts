import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashScreenComponent } from './dash-screen.component';

describe('DashScreenComponent', () => {
  let component: DashScreenComponent;
  let fixture: ComponentFixture<DashScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
