import {Component, OnDestroy, OnInit} from '@angular/core';
import {TaskDashApiService} from '../../services/task-dash-api.service';
import {TaskSummaryModel} from '../../models/taskSummary.model';
import {ContentLoadingOverlayService} from '../../../Common/services/content-loading-overlay/content-loading-overlay.service';
import {AuthService, RoleTypes} from '../../../../session/auth.service';

@Component({
  selector: 'app-dash-screen',
  templateUrl: './dash-screen.component.html',
  styleUrls: ['./dash-screen.component.scss']
})
export class DashScreenComponent implements OnInit, OnDestroy {
  readonly componentKey = 'dash-screen-component';
  summary: TaskSummaryModel;
  RoleTypes = RoleTypes;

  constructor(
    public dashApi: TaskDashApiService,
    public loader: ContentLoadingOverlayService,
    public authService: AuthService
  ) { }

  ngOnInit() {
    this.loader.pushLoad(this.componentKey);

    this.dashApi.getSummary().subscribe( summary => {
      this.summary = summary;
      this.loader.popLoad(this.componentKey);
    } );
  }

  ngOnDestroy(): void {
    this.loader.signOut(this.componentKey);
  }

}
