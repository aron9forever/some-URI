import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import {SharedModule} from '../Common/shared.module';
import {DashScreenComponent} from './pages/dash-screen/dash-screen.component';
import {DashRoutes} from './dash.routes';
import {TaskDashApiService} from './services/task-dash-api.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(DashRoutes),
    SharedModule
  ],
  providers: [
    TaskDashApiService
  ],
  declarations: [
    DashScreenComponent
  ]
})
export class DashModule { }
