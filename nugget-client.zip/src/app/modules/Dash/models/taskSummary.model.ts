import * as moment from 'moment';

export class TaskSummaryModel {
  pickup_count: number;
  today: any;

  static fromJson(data) {
    const obj = Object.assign(new TaskSummaryModel, data);

    obj.today = moment(obj.today);

    return obj;
  }
}
