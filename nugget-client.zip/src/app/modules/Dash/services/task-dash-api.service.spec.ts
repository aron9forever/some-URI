import { TestBed } from '@angular/core/testing';

import { TaskDashApiService } from './task-dash-api.service';

describe('TaskDashApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TaskDashApiService = TestBed.get(TaskDashApiService);
    expect(service).toBeTruthy();
  });
});
