import { Routes } from '@angular/router';
import {DashScreenComponent} from './pages/dash-screen/dash-screen.component';

export const DashRoutes: Routes = [
  {
    path: '',
    component: DashScreenComponent,
  }
];
