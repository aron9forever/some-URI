import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../../../../environments/environment';
import {PickupModel} from '../models/pickup.model';
import {HttpUtil} from '../../Common/utils/http.util';


@Injectable({
  providedIn: 'root'
})
export class PickupApiService {

  constructor(
    private httpClient: HttpClient
  ) { }

  public getPickups(qdata = {}): Observable<PickupModel[]> {
    let params = HttpUtil.objectToHttpParam(qdata);

    return this.httpClient
      .get<PickupModel[]>(environment.apiUrl + 'pickups/', {params})
      .map((results) => {
        results['pickups'].forEach( (serverData, index, array) => {
          array[index] = PickupModel.fromJson(serverData);
        } );

        return results['pickups'];
      });
  }

  public getDailyPickups(qdata) {
    return this.httpClient
      .post<PickupModel[]>(environment.apiUrl + 'pickups/daily', qdata)
      .map((results) => {
        results['pickups'].forEach( (serverData, index, array) => {
          array[index] = PickupModel.fromJson(serverData);
        } );

        return results['pickups'];
      });
  }

  public postPickup(data) {
    return this.httpClient.post(environment.apiUrl + 'pickups', data);
  }

  public deletePickup(id) {
    return this.httpClient.delete(environment.apiUrl + 'pickups/' + id, {});
  }
}
