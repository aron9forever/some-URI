import { TestBed } from '@angular/core/testing';

import { PickupApiService } from './pickup-api.service';

describe('PickupApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PickupApiService = TestBed.get(PickupApiService);
    expect(service).toBeTruthy();
  });
});
