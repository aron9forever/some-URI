import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {HttpUtil} from '../../Common/utils/http.util';
import {environment} from '../../../../environments/environment';
import {PartyModel} from '../models/party.model';


export enum PARTY_TYPES {
  CUSTOMER = "\\App\\Entity\\CustomerParty",
  WAREHOUSE = "\\App\\Entity\\WarehouseParty",
  HAULIER = "\\App\\Entity\\HaulierParty",
}

@Injectable({
  providedIn: 'root'
})
export class PartyApiService {

  constructor(
    private httpClient: HttpClient
  ) { }

  public getParties(type: PARTY_TYPES): Observable<PartyModel[]> {
    let params = HttpUtil.objectToHttpParam({type: type});

    return this.httpClient
      .get<PartyModel[]>(environment.apiUrl + 'parties/', {params})
      .map((results) => {
        results['parties'].forEach( (serverData, index, array) => {
          array[index] = PartyModel.fromJson(serverData);
        } );

        return results['parties'];
      });
  }
}
