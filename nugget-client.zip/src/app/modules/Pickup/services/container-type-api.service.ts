import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../../../../environments/environment';
import {ContainerTypeModel} from '../models/container-type.model';

@Injectable({
  providedIn: 'root'
})
export class ContainerTypeApiService {

  constructor(
    private httpClient: HttpClient
  ) { }

  public getContainerTypes(): Observable<ContainerTypeModel[]> {
    return this.httpClient
      .get<ContainerTypeModel[]>(environment.apiUrl + 'containertypes/', {})
      .map((results) => {
        results['container_types'].forEach( (serverData, index, array) => {
          array[index] = ContainerTypeModel.fromJson(serverData);
        } );

        return results['container_types'];
      });
  }
}
