import { TestBed } from '@angular/core/testing';

import { ContainerTypeApiService } from './container-type-api.service';

describe('ContainerTypeApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContainerTypeApiService = TestBed.get(ContainerTypeApiService);
    expect(service).toBeTruthy();
  });
});
