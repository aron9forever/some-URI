import { TestBed } from '@angular/core/testing';

import { PartyApiService } from './party-api.service';

describe('PartyApiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PartyApiService = TestBed.get(PartyApiService);
    expect(service).toBeTruthy();
  });
});
