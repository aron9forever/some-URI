import {Component, OnDestroy, OnInit} from '@angular/core';
import {PickupApiService} from '../../services/pickup-api.service';
import {PickupModel} from '../../models/pickup.model';
import {ContentLoadingOverlayService} from '../../../Common/services/content-loading-overlay/content-loading-overlay.service';

@Component({
  selector: 'app-pickup-list-page',
  templateUrl: './pickup-list-page.component.html',
  styleUrls: ['./pickup-list-page.component.scss']
})
export class PickupListPageComponent implements OnInit, OnDestroy {
  private componentKey = 'pickup-list-page';
  public pickups: PickupModel[] = [];

  iconsCss = { sortAscending: 'glyphicon glyphicon-chevron-down', sortDescending: 'glyphicon glyphicon-chevron-up', pagerLeftArrow: 'glyphicon glyphicon-chevron-left', pagerRightArrow: 'glyphicon glyphicon-chevron-right', pagerPrevious: 'glyphicon glyphicon-backward', pagerNext: 'glyphicon glyphicon-forward' };

  constructor(
    private pickupApi: PickupApiService,
    private loader: ContentLoadingOverlayService
  ) { }

  ngOnInit() {
    this.loadPickups();
  }

  ngOnDestroy(): void {
    this.loader.signOut(this.componentKey);
  }

  loadPickups() {
    this.loader.pushLoad(this.componentKey);
    this.pickupApi.getPickups().subscribe( pickups => {
      console.log(pickups);
      this.pickups = pickups;
      this.loader.popLoad(this.componentKey);
    } );
  }

}
