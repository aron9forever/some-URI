import {Component, OnDestroy, OnInit} from '@angular/core';
import {PARTY_TYPES, PartyApiService} from '../../services/party-api.service';
import {PartyModel} from '../../models/party.model';
import {ContentLoadingOverlayService} from '../../../Common/services/content-loading-overlay/content-loading-overlay.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import * as moment from 'moment';
import {ContainerTypeApiService} from '../../services/container-type-api.service';
import {ContainerTypeModel} from '../../models/container-type.model';
import Swal from "sweetalert2";
import {PickupApiService} from '../../services/pickup-api.service';
import {LanguageBookService} from '../../../Common/services/language-book/language-book.service';

@Component({
  selector: 'app-create-pickup-page',
  templateUrl: './create-pickup-page.component.html',
  styleUrls: ['./create-pickup-page.component.scss']
})
export class CreatePickupPageComponent implements OnInit, OnDestroy {
  readonly componentKey = 'create-pickup-page';
  public customers: PartyModel[] = [];
  public warehouses: PartyModel[] = [];
  public hauliers: PartyModel[] = [];
  public containerTypes: ContainerTypeModel[] = [];

  formGroup = this._formBuilder.group({
    customer_id: ['', [Validators.required]],
    warehouse_id: ['', [Validators.required]],
    haulier_id: ['', [Validators.required]],
    date: [moment(new Date()), [Validators.required]],
    container_type_id: ['', [Validators.required]],
    repeat_count: ['', []],
    repeat_interval_minutes: ['', []],
  });

  constructor(
    private _formBuilder: FormBuilder,
    private partyService: PartyApiService,
    private containerTypeService: ContainerTypeApiService,
    private pickupService: PickupApiService,
    private loader: ContentLoadingOverlayService,
    private lang: LanguageBookService
  ) { }

  ngOnInit() {
    this.getCustomers();
    this.getWarehouses();
    this.getHauliers();
    this.getContainerTypes();
  }

  ngOnDestroy(): void {
    this.loader.signOut(this.componentKey);
  }

  getCustomers() {
    this.loader.pushLoad(this.componentKey);
    this.partyService.getParties(PARTY_TYPES.CUSTOMER).subscribe( data => {
      this.customers = data;
      this.loader.popLoad(this.componentKey);
    } );
  }

  getWarehouses() {
    this.loader.pushLoad(this.componentKey);
    this.partyService.getParties(PARTY_TYPES.WAREHOUSE).subscribe( data => {
      this.warehouses = data;
      this.loader.popLoad(this.componentKey);
    } );
  }

  getHauliers() {
    this.loader.pushLoad(this.componentKey);
    this.partyService.getParties(PARTY_TYPES.HAULIER).subscribe( data => {
      this.hauliers = data;
      this.loader.popLoad(this.componentKey);
    } );
  }

  getContainerTypes() {
    this.loader.pushLoad(this.componentKey);
    this.containerTypeService.getContainerTypes().subscribe( data => {
      this.containerTypes = data;
      this.loader.popLoad(this.componentKey);
    } );
  }

  savePickup() {
    if(this.formGroup.valid) {
      let newData = {
        'container_type': {id: this.formGroup.value.container_type_id},
        'customer': {id: this.formGroup.value.customer_id},
        'warehouse': {id: this.formGroup.value.warehouse_id},
        'haulier': {id: this.formGroup.value.haulier_id},
        'date': this.formGroup.value.date.format(),
        'repeat_count': this.formGroup.value.repeat_count,
        'repeat_interval_minutes': this.formGroup.value.repeat_interval_minutes,
      };

      this.loader.pushLoad(this.componentKey);
      this.pickupService.postPickup(newData).subscribe( data => {
        this.loader.popLoad(this.componentKey);
        Swal({
          title: data['message'],
          type: 'success',
          confirmButtonText: this.lang.book.BUTTONS.CLOSE,
          heightAuto: false,
        }).then(result => {
        });
      } );
    }
  }

  hasRequiredError(form, key: string) {
    return (form.controls[key].hasError('required') &&
      (form.controls[key].touched || form.controls[key].dirty));
  }

  /**
   * Marks all controls in a form group as touched
   * @param formGroup - The group to caress..hah
   */
  public markFormGroupTouched(formGroup: FormGroup) {
    (<any>Object).values(formGroup.controls).forEach(control => {
      control.markAsTouched();

      if (control.controls) {
        this.markFormGroupTouched(control);
      }
    });
  }
}
