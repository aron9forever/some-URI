import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePickupPageComponent } from './create-pickup-page.component';

describe('CreatePickupPageComponent', () => {
  let component: CreatePickupPageComponent;
  let fixture: ComponentFixture<CreatePickupPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePickupPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePickupPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
