import { Component, OnInit } from '@angular/core';
import {PickupApiService} from '../../services/pickup-api.service';
import {ContentLoadingOverlayService} from '../../../Common/services/content-loading-overlay/content-loading-overlay.service';
import {PickupModel} from '../../models/pickup.model';
import * as moment from 'moment';

@Component({
  selector: 'app-pickup-daily-list-page',
  templateUrl: './pickup-daily-list-page.component.html',
  styleUrls: ['./pickup-daily-list-page.component.scss']
})
export class PickupDailyListPageComponent implements OnInit {
  private componentKey = 'pickup-daily-list-page';
  public pickups: PickupModel[] = [];
  iconsCss = { sortAscending: 'glyphicon glyphicon-chevron-down', sortDescending: 'glyphicon glyphicon-chevron-up', pagerLeftArrow: 'glyphicon glyphicon-chevron-left', pagerRightArrow: 'glyphicon glyphicon-chevron-right', pagerPrevious: 'glyphicon glyphicon-backward', pagerNext: 'glyphicon glyphicon-forward' };
  _viewingDate = moment(new Date());

  constructor(
    private pickupApi: PickupApiService,
    private loader: ContentLoadingOverlayService
  ) { }

  ngOnInit() {
    this.loadPickups();
  }

  get viewingDate() {
    return this._viewingDate;
  }

  set viewingDate(val) {
    this._viewingDate = val;
    this.loadPickups();
  }

  ngOnDestroy(): void {
    this.loader.signOut(this.componentKey);
  }

  loadPickups() {
    this.loader.pushLoad(this.componentKey);
    this.pickupApi.getDailyPickups({date: encodeURI(this.viewingDate.format())}).subscribe( pickups => {
      console.log(pickups);
      this.pickups = pickups;
      this.loader.popLoad(this.componentKey);
    } );
  }

}
