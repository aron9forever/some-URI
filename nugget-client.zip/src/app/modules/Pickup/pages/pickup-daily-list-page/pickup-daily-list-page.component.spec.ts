import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PickupDailyListPageComponent } from './pickup-daily-list-page.component';

describe('PickupDailyListPageComponent', () => {
  let component: PickupDailyListPageComponent;
  let fixture: ComponentFixture<PickupDailyListPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PickupDailyListPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PickupDailyListPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
