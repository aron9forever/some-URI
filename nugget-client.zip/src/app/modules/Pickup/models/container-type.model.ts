export class ContainerTypeModel {
  id: number;
  name: string;
  code: string;

  static fromJson(data) {
    return Object.assign(new ContainerTypeModel, data);
  }
}
