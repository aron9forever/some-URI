import {ContainerTypeModel} from './container-type.model';

export class ContainerModel {
  id: number;
  container_type: ContainerTypeModel;
  number: string;
  weight: number;

  static fromJson(data) {
    const obj = Object.assign(new ContainerModel, data);

    return obj;
  }
}
