export class PartyModel {
  id: number;
  name: string;
  type: string;

  static fromJson(data) {
    return Object.assign(new PartyModel, data);
  }
}
