import {PartyModel} from './party.model';
import {ContainerModel} from './container.model';
import * as moment from 'moment';
import {Moment} from 'moment';

export class PickupModel {
  id: number;
  customer: PartyModel;
  warehouse: PartyModel;
  haulier: PartyModel;
  container: ContainerModel;
  date: string;
  created_at: Moment;
  updated_at: Moment;

  static fromJson(data) {
    const obj: PickupModel = Object.assign(new PickupModel, data);

    obj.container = ContainerModel.fromJson(obj.container);
    obj.customer = PartyModel.fromJson(obj.customer);
    obj.warehouse = PartyModel.fromJson(obj.warehouse);
    obj.haulier = PartyModel.fromJson(obj.haulier);

    if(data['created_at']) {
      obj.created_at = moment(obj.created_at);
    }
    if(data['updated_at']) {
      obj.updated_at = moment(obj.updated_at);
    }

    return obj;
  }
}
