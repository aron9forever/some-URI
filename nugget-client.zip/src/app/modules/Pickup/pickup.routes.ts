import { Routes } from '@angular/router';
import {PickupListPageComponent} from './pages/pickup-list-page/pickup-list-page.component';
import {PickupDailyListPageComponent} from './pages/pickup-daily-list-page/pickup-daily-list-page.component';
import {CreatePickupPageComponent} from './pages/create-pickup-page/create-pickup-page.component';
import {AuthGuard} from '../../session/auth.guard';

export const PickupRoutes: Routes = [
  {
    path: 'list',
    component: PickupListPageComponent,
    //canActivate: [AdminGuard]
  },
  {
    path: 'daily-list',
    component: PickupDailyListPageComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'create',
    component: CreatePickupPageComponent,
    canActivate: [AuthGuard]
  },
];
