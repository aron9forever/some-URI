
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import {SharedModule} from '../Common/shared.module';
import {PickupRoutes} from './pickup.routes';
import {PartyApiService} from './services/party-api.service';
import {PickupApiService} from './services/pickup-api.service';
import {PickupListPageComponent} from './pages/pickup-list-page/pickup-list-page.component';
import { PickupDailyListPageComponent } from './pages/pickup-daily-list-page/pickup-daily-list-page.component';
import { CreatePickupPageComponent } from './pages/create-pickup-page/create-pickup-page.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(PickupRoutes),
    SharedModule
  ],
  providers: [
    PartyApiService,
    PickupApiService
  ],
  declarations: [
    PickupListPageComponent,
    PickupDailyListPageComponent,
    CreatePickupPageComponent
  ],
  entryComponents: [
  ]
})
export class PickupModule { }
