import { Routes } from '@angular/router';
import {E404Component} from './pages/e404/e404.component';
import {E403Component} from './pages/e403/e403.component';

export const ErrorRoutes: Routes = [
  {
    path: '404',
    component: E404Component
  },
  {
    path: '403',
    component: E403Component
  },
];
