import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import {ErrorRoutes} from './error.routes';
import {SharedModule} from '../Common/shared.module';
import {E404Component} from './pages/e404/e404.component';
import { E403Component } from './pages/e403/e403.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(ErrorRoutes)
  ],
  declarations: [E404Component, E403Component]
})
export class ErrorModule { }
