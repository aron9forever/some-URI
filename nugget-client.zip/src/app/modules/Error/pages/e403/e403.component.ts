import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e403',
  templateUrl: './e403.component.html',
  styleUrls: ['./e403.component.scss']
})
export class E403Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
