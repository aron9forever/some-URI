<?php


namespace App\Traits;


use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

trait RepoFindOrFailTrait
{
    /**
     * @param int $id
     * @return mixed
     */
    public function findOrFail(int $id)
    {
        $ent = $this->find($id);

        if (!$ent) {
            throw new NotFoundHttpException("{$this->getShortClassName()} not found.");
        }

        return $ent;
    }

    /**
     * @param $criteria
     * @return mixed
     */
    public function findOneByOrFail($criteria)
    {
        $ent = $this->findOneBy($criteria);
        $q = json_encode($criteria);

        if (!$ent) {
            throw new NotFoundHttpException("{$this->getShortClassName()} with {$q} not found.");
        }

        return $ent;
    }

    private function getShortClassName()
    {
        return substr($this->getClassName(), strrpos($this->getClassName(), '\\') + 1);
    }
}
