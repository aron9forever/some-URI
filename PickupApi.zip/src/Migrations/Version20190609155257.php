<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190609155257 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE party (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, type VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE pickup (id INT AUTO_INCREMENT NOT NULL, customer_id INT NOT NULL, warehouse_id INT NOT NULL, haulier_id INT NOT NULL, container_id INT NOT NULL, date DATETIME NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL, INDEX IDX_419E39FD9395C3F3 (customer_id), INDEX IDX_419E39FD5080ECDE (warehouse_id), INDEX IDX_419E39FDE41BD2EA (haulier_id), UNIQUE INDEX UNIQ_419E39FDBC21F742 (container_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, email VARCHAR(180) NOT NULL, roles JSON NOT NULL, password VARCHAR(255) NOT NULL, UNIQUE INDEX UNIQ_8D93D649E7927C74 (email), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE container_type (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, code VARCHAR(4) NOT NULL, UNIQUE INDEX UNIQ_425B7A677153098 (code), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE container (id INT AUTO_INCREMENT NOT NULL, container_type_id INT NOT NULL, number VARCHAR(11) DEFAULT NULL, weight NUMERIC(10, 2) DEFAULT NULL, INDEX IDX_C7A2EC1B5B3408DE (container_type_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE pickup ADD CONSTRAINT FK_419E39FD9395C3F3 FOREIGN KEY (customer_id) REFERENCES party (id)');
        $this->addSql('ALTER TABLE pickup ADD CONSTRAINT FK_419E39FD5080ECDE FOREIGN KEY (warehouse_id) REFERENCES party (id)');
        $this->addSql('ALTER TABLE pickup ADD CONSTRAINT FK_419E39FDE41BD2EA FOREIGN KEY (haulier_id) REFERENCES party (id)');
        $this->addSql('ALTER TABLE pickup ADD CONSTRAINT FK_419E39FDBC21F742 FOREIGN KEY (container_id) REFERENCES container (id)');
        $this->addSql('ALTER TABLE container ADD CONSTRAINT FK_C7A2EC1B5B3408DE FOREIGN KEY (container_type_id) REFERENCES container_type (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE pickup DROP FOREIGN KEY FK_419E39FD9395C3F3');
        $this->addSql('ALTER TABLE pickup DROP FOREIGN KEY FK_419E39FD5080ECDE');
        $this->addSql('ALTER TABLE pickup DROP FOREIGN KEY FK_419E39FDE41BD2EA');
        $this->addSql('ALTER TABLE container DROP FOREIGN KEY FK_C7A2EC1B5B3408DE');
        $this->addSql('ALTER TABLE pickup DROP FOREIGN KEY FK_419E39FDBC21F742');
        $this->addSql('DROP TABLE party');
        $this->addSql('DROP TABLE pickup');
        $this->addSql('DROP TABLE user');
        $this->addSql('DROP TABLE container_type');
        $this->addSql('DROP TABLE container');
    }
}
