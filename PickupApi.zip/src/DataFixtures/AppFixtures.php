<?php

namespace App\DataFixtures;

use App\Entity\ContainerType;
use App\Entity\CustomerParty;
use App\Entity\HaulierParty;
use App\Entity\User;
use App\Entity\WarehouseParty;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    const CONTAINER_TYPES = array(
        array('name' => '20 BULK CONTAINER','code' => '22BU'),
        array('name' => '20 GENERAL PURPOSE CONT.','code' => '22GP'),
        array('name' => '20 INSULATED CONTAINER','code' => '22HR'),
        array('name' => '20 FLAT (FIXED ENDS)','code' => '22PF'),
        array('name' => 'Uncontainerised','code' => '8888'),
        array('name' => '20 FLAT (COLLAPSIBLE)','code' => '22PC'),
        array('name' => '20 REEFER CONTAINER','code' => '22RT'),
        array('name' => '20 TANK CONTAINER','code' => '22TN'),
        array('name' => '20 OPEN TOP CONTAINER','code' => '22UT'),
        array('name' => '20 HARDTOP CONTAINER','code' => '22UP'),
        array('name' => '20 VENTILATED CONTAINER','code' => '22VH'),
        array('name' => '20 PLATFORM','code' => '29PL'),
        array('name' => '40 GENERAL PURPOSE CONT.','code' => '42GP'),
        array('name' => '40 INSULATED CONTAINER','code' => '42HR'),
        array('name' => '40 FLAT (FIXED ENDS)','code' => '42PF'),
        array('name' => '40 FLAT (COLLAPSIBLE)','code' => '42PC'),
        array('name' => '40 REEFER CONTAINER','code' => '42RT'),
        array('name' => '40 TANK CONTAINER','code' => '42TD'),
        array('name' => '40 OPEN TOP CONTAINER','code' => '42UT'),
        array('name' => '40 HARDTOP CONTAINER','code' => '42UP'),
        array('name' => '40 VENTILATED CONTAINER','code' => '42VH'),
        array('name' => '40 HIGH CUBE CONT.','code' => '45GP'),
        array('name' => '40 REEFER HIGHCUBE CONTAINER','code' => '45RT'),
        array('name' => '40 HIGH CUBE HARDTOP CONT.','code' => '45UP'),
        array('name' => '40 PLATFORM','code' => '49PL'),
        array('name' => '45 HIGH CUBE CONT.','code' => 'L5GP'),
        array('name' => '45 REEFER HIGHCUBE CONTAINER','code' => 'L5R1'),
        array('name' => 'FLATBED','code' => '12TR')
    );

    const PARTIES = array(
        array('name' => '123 Tainers Co.','type' => CustomerParty::class),
        array('name' => 'Seed Enterprise Inc.','type' => CustomerParty::class),
        array('name' => 'GOT Enterprises','type' => CustomerParty::class),
        array('name' => '123 Wares Inc.','type' => WarehouseParty::class),
        array('name' => 'Red Keep','type' => WarehouseParty::class),
        array('name' => '456 Wares Inc.','type' => WarehouseParty::class),
        array('name' => 'XYZ Haulers TLD','type' => HaulierParty::class),
        array('name' => 'ABC Haulers TLD','type' => HaulierParty::class),
        array('name' => 'Targaryen','type' => HaulierParty::class)
    );

    public function load(ObjectManager $manager)
    {
        foreach (self::CONTAINER_TYPES as $CONTAINER_TYPE) {
            $type = new ContainerType();
            $type->setName($CONTAINER_TYPE['name']);
            $type->setCode($CONTAINER_TYPE['code']);
            $manager->persist($type);
        }

        foreach (self::PARTIES as $PARTY) {
            $p = new $PARTY['type'];
            $p->setName($PARTY['name']);
            $manager->persist($p);
        }

        $user = new User();
        $user->setEmail('test@test.com');
        $user->setPassword('$2y$13$NW3TGZjSSmHKxptk2F3L9O8O5Jcz2WMnxJQjwGG1I1UxtcZCOfCc.');
        $manager->persist($user);

        $manager->flush();
    }
}
