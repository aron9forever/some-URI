<?php


namespace App\Controller;


use App\Entity\Container;
use App\Entity\Pickup;
use App\Repository\PartyRepository;
use DateInterval;
use FOS\RestBundle\Controller\AbstractFOSRestController;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Routing\ClassResourceInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PartyController
 * @package App\Controller
 * @RouteResource("Party")
 */
class PartyController extends AbstractFOSRestController implements ClassResourceInterface
{
    private $party_repository;

    public function __construct(
        PartyRepository $partyRepository
    )
    {
        $this->party_repository = $partyRepository;
    }

    /**
     * Get the list of parties.
     *
     * @param ParamFetcherInterface $paramFetcher
     * @return Response
     *
     * @QueryParam(name="type", nullable=true, description="Type of parties to fetch")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        $qb = $this->party_repository->createQueryBuilder("e");

        if ($paramFetcher->get('type')) {
            $qb->andWhere($qb->expr()->isInstanceOf('e', $paramFetcher->get('type')));
        }
        ;
        $result = $qb->getQuery()->getResult();

        return new JsonResponse(["parties" => $result]);
    }

    /**
     * Get a single party.
     *
     * @param $id
     * @return Response
     *
     */
    public function getAction($id)
    {
        $result = $this->party_repository->findOrFail($id);

        return new JsonResponse(["party" => $result]);
    }
}
