<?php


namespace App\Controller;


use App\Entity\Container;
use App\Entity\Pickup;
use App\Repository\ContainerTypeRepository;
use App\Repository\PartyRepository;
use DateInterval;
use FOS\RestBundle\Controller\AbstractFOSRestController;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Routing\ClassResourceInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ContainerTypeController
 * @package App\Controller
 * @RouteResource("ContainerType")
 */
class ContainerTypeController extends AbstractFOSRestController implements ClassResourceInterface
{
    private $container_type_repository;

    public function __construct(ContainerTypeRepository $containerTypeRepository)
    {
        $this->container_type_repository = $containerTypeRepository;
    }

    /**
     * Get the list of container types.
     *
     * @param ParamFetcherInterface $paramFetcher
     * @return Response
     *
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        $result = $this->container_type_repository->findAll();

        return new JsonResponse(["container_types" => $result]);
    }
}
