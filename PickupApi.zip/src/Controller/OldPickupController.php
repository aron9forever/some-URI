<?php

namespace App\Controller;

use App\Entity\Container;
use App\Entity\Pickup;
use App\Repository\ContainerTypeRepository;
use App\Repository\PartyRepository;
use App\Repository\PickupRepository;
use App\Service\ValidationErrorParser;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Service\JsonSerializer;
use Symfony\Component\Validator\Validator\ValidatorInterface;

/**
 * @Route("/ppickup", name="Pickups")
 */
class OldPickupController extends AbstractController
{
    /**
     * @param int $id
     * @param PickupRepository $pickupRepository
     * @return Response
     * @Route("/{id}", name="pickups_get", methods={"GET","HEAD"}, requirements={"id"="\d+"})
     */
    public function read($id, PickupRepository $pickupRepository)
    {
        $ent = $pickupRepository->find($id);

        if (!$ent) {
            return new JsonResponse('Pickup not found!', 404);
        }

        return new JsonResponse(["pickup" => $ent->jsonSerialize()]);
    }

    /**
     * @param PickupRepository $pickupRepository
     * @return JsonResponse
     * @Route("/", name="pickups_list", methods={"GET","HEAD"})
     */
    public function index(PickupRepository $pickupRepository)
    {
        $pickups = $pickupRepository->findAll();
//        dd($pickups);
//        $pickupsArr = [];
//
//        foreach ($pickups as $pickup) {
//            $pickupsArr[] = $pickup->jsonSerialize();
//        }

        return new JsonResponse(["pickups" => $pickups]);
    }

    /**
     * @param Request $request
     * @param ValidatorInterface $validator
     * @param PartyRepository $partyRepository
     * @param ValidationErrorParser $validationErrorParser
     * @return JsonResponse
     * @throws \Exception
     * @Route("/", name="pickups_create", methods={"POST"})
     */
    public function create(
        Request $request,
        ValidatorInterface $validator,
        PartyRepository $partyRepository,
        ContainerTypeRepository $containerTypeRepository,
        ValidationErrorParser $validationErrorParser
    )
    {
        $containerType = $containerTypeRepository->findOneBy($request->get('container_type'));
        $container = new Container($containerType);

        $pickup = new Pickup();
        $pickup->setDate(new \DateTime($request->get('date')));
        $pickup->setCustomer(
            $partyRepository->findOneBy($request->get('customer'))
        );
        $pickup->setWarehouse(
            $partyRepository->findOneBy($request->get('warehouse'))
        );
        $pickup->setHaulier(
            $partyRepository->findOneBy($request->get('haulier'))
        );
        $pickup->setContainer($container);

        if (count($errors = $validator->validate($pickup))) {
            return new JsonResponse(['errors' => $validationErrorParser->toArray($errors)], 422);
        }

        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->persist($pickup);
        $entityManager->flush();

        return new JsonResponse('Pickup created!');
    }

    /**
     * @param int $id
     * @param PickupRepository $pickupRepository
     * @return Response
     * @Route("/{id}", name="pickups_delete", methods={"DELETE"}, requirements={"id"="\d+"})
     */
    public function delete($id, PickupRepository $pickupRepository)
    {
        $ent = $pickupRepository->find($id);

        if (!$ent) {
            return new JsonResponse('Pickup not found!', 404);
        }

        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($ent);
        $entityManager->flush();

        return new JsonResponse('Pickup deleted!');
    }
}
