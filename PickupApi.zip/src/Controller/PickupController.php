<?php


namespace App\Controller;


use App\Entity\Container;
use App\Entity\Pickup;
use App\Repository\ContainerTypeRepository;
use App\Repository\PartyRepository;
use App\Repository\PickupRepository;
use DateInterval;
use DateTime;
use FOS\RestBundle\Controller\AbstractFOSRestController;
use FOS\RestBundle\Request\ParamFetcherInterface;
use FOS\RestBundle\Routing\ClassResourceInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use FOS\RestBundle\Controller\Annotations\RouteResource;
use FOS\RestBundle\Controller\Annotations\QueryParam;
use FOS\RestBundle\Controller\Annotations\RequestParam;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PickupController
 * @package App\Controller
 * @RouteResource("Pickup")
 */
class PickupController extends AbstractFOSRestController implements ClassResourceInterface
{
    private $pickup_repository, $container_type_repository, $party_repository;

    public function __construct(
        PickupRepository $pickupRepository,
        ContainerTypeRepository $containerTypeRepository,
        PartyRepository $partyRepository
    )
    {
        $this->pickup_repository = $pickupRepository;
        $this->container_type_repository = $containerTypeRepository;
        $this->party_repository = $partyRepository;
    }

    /**
     * Get the list of pickups.
     *
     * @param ParamFetcherInterface $paramFetcher
     * @return Response
     *
     * @QueryParam(name="page", requirements="\d+", default="1", description="Page of the overview.")
     * @QueryParam(name="count", requirements="\d+", strict=true, nullable=true, description="Item count limit")
     * @QueryParam(name="sort", requirements="(asc|desc)", allowBlank=false, default="asc", description="Sort direction")
     */
    public function cgetAction(ParamFetcherInterface $paramFetcher)
    {
        $criteria = [];

        $result = $this->pickup_repository->findBy($criteria);

        return new JsonResponse(["pickups" => $result]);
    }

    /**
     * @param ParamFetcherInterface $paramFetcher
     * @return JsonResponse
     * @throws \Exception
     *
     * @Route("/api/pickups/daily", name="pickups_daily", methods={"POST"})
     * @RequestParam(name="date", nullable=true, description="Day for which to return pickups")
     */
    public function getByDate(ParamFetcherInterface $paramFetcher)
    {
        $date = \DateTime::createFromFormat(\DateTime::ATOM, $paramFetcher->get('date'));

        $from = new DateTime($date->format("Y-m-d")." 00:00:00");
        $to   = new DateTime($date->format("Y-m-d")." 23:59:59");

        $qb = $this->pickup_repository->createQueryBuilder("e");
        $qb
            ->andWhere('e.date BETWEEN :from AND :to')
            ->setParameter('from', $from )
            ->setParameter('to', $to)
        ;
        $result = $qb->getQuery()->getResult();

        return new JsonResponse(["pickups" => $result]);
    }

    /**
     * Get a single pickup.
     *
     * @param $id
     * @return Response
     *
     */
    public function getAction($id)
    {
        $result = $this->pickup_repository->findOrFail($id);

        return new JsonResponse(["pickup" => $result]);
    }

    /**
     * @param ParamFetcherInterface $paramFetcher
     * @return Response
     * @throws \Exception
     *
     * @RequestParam(name="container_type", default=null, nullable=false, description="Array of search terms for Container Type")
     * @RequestParam(name="date", nullable=false, requirements="^([\+-]?\d{4}(?!\d{2}\b))((-?)((0[1-9]|1[0-2])(\3([12]\d|0[1-9]|3[01]))?|W([0-4]\d|5[0-2])(-?[1-7])?|(00[1-9]|0[1-9]\d|[12]\d{2}|3([0-5]\d|6[1-6])))([T\s]((([01]\d|2[0-3])((:?)[0-5]\d)?|24\:?00)([\.,]\d+(?!:))?)?(\17[0-5]\d([\.,]\d+)?)?([zZ]|([\+-])([01]\d|2[0-3]):?([0-5]\d)?)?)?)?$")
     * @RequestParam(name="customer",  nullable=false, description="Array of search terms for Customer Party")
     * @RequestParam(name="warehouse",  nullable=false, description="Array of search terms for Warehouse Party")
     * @RequestParam(name="haulier",  nullable=false, description="Array of search terms for Haulier Party")
     * @RequestParam(name="repeat_count", requirements="\d+", default=0, nullable=false, description="How many times the pickup will repeat")
     * @RequestParam(name="repeat_interval_minutes", requirements="\d+", default=0, nullable=false, description="How many minutes between repeated pickups")
     */
    public function postAction(ParamFetcherInterface $paramFetcher)
    {
        $repeats = $paramFetcher->get('repeat_count');
        $repeat_interval = $paramFetcher->get('repeat_interval_minutes');
        $date = \DateTime::createFromFormat(\DateTime::ATOM, $paramFetcher->get('date'));
        $entityManager = $this->getDoctrine()->getManager();

        $containerType = $this->container_type_repository->findOneByOrFail($paramFetcher->get('container_type'));
        $container = new Container($containerType);

        for ($pickups = 0; $pickups <= $repeats; $pickups++) {
            $pickup = new Pickup();
            $pickup->setDate(clone $date);
            $pickup->setCustomer($this->party_repository->findOneByOrFail($paramFetcher->get('customer')));
            $pickup->setWarehouse($this->party_repository->findOneByOrFail($paramFetcher->get('warehouse')));
            $pickup->setHaulier($this->party_repository->findOneByOrFail($paramFetcher->get('haulier')));
            $pickup->setContainer(clone $container);
            $entityManager->persist($pickup);

            if($repeats) {
                $date->add(new DateInterval('PT' . $repeat_interval . 'M'));
            }
        }

        $entityManager->flush();

        return new JsonResponse(["message" => "Pickup" . ($repeats?'s':'') . " created!"]);
    }

    /**
     * @param $id
     * @param ParamFetcherInterface $paramFetcher
     * @return Response
     * @throws \Exception
     *
     * @RequestParam(name="container_number", requirements="([a-zA-Z]{3})([UJZujz])(\d{6})(\d)", default=null, nullable=true, description="ISO 6346 Container Number")
     * @RequestParam(name="container_weight", requirements=@Assert\Positive, default=null, nullable=true, description="Decimal Container Weight")
     */
    public function patchAction($id, ParamFetcherInterface $paramFetcher)
    {
        $result = $this->pickup_repository->findOrFail($id);
        $container = $result->getContainer();

        if ($paramFetcher->get('container_weight'))
            $container->setWeight($paramFetcher->get('container_weight'));
        if ($paramFetcher->get('container_number'))
            $container->setNumber($paramFetcher->get('container_number'));

        $this->getDoctrine()->getManager()->flush();

        return new JsonResponse(["pickup" => $result]);
    }

    /**
     * Delete a pickup.
     *
     * @param $id
     * @return Response
     */
    public function deleteAction($id)
    {
        $ent = $this->pickup_repository->findOrFail($id);

        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($ent);
        $entityManager->flush();

        return new JsonResponse(['message' => 'Pickup deleted!']);
    }

    /**
     * @return JsonResponse
     * @throws \Doctrine\ORM\NonUniqueResultException
     *
     * @Route("/api/stats", name="pickups_stats", methods={"GET"})
     */
    public function stats()
    {
        $pickup_count = $this->pickup_repository->createQueryBuilder('u')
            ->select('count(u.id)')
            ->getQuery()
            ->getSingleScalarResult();


        return new JsonResponse(['pickup_count' => $pickup_count]);
    }
}
