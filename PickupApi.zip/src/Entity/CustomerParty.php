<?php


namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;


/**
 * @ORM\Entity()
 */
class CustomerParty extends Party
{
    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Pickup", mappedBy="customer", fetch="LAZY")
     */
    protected $pickups;
}
