<?php


namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity()
 */
class WarehouseParty extends Party
{
    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Pickup", mappedBy="warehouse", fetch="LAZY")
     */
    protected $pickups;
}
