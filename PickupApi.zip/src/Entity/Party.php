<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PartyRepository")
 * @ORM\InheritanceType("SINGLE_TABLE")
 * @ORM\DiscriminatorColumn(name="type", type="string")
 * @ORM\DiscriminatorMap({"generic" = "Party", "customer" = "CustomerParty", "warehouse" = "WarehouseParty", "haulier" = "HaulierParty"})
 */
class Party implements \JsonSerializable
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups({"pickup_minimal"})
     */
    protected $id;

    protected $pickups;

    /**
     * @ORM\Column(type="string", length=255)
     * @Groups({"pickup_minimal"})
     */
    protected $name;

    public function __construct()
    {
        $this->pickups = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection|Pickup[]
     */
    public function getPickups(): Collection
    {
        return $this->pickups;
    }

    public function addPickup(Pickup $pickup): self
    {
        if (!$this->pickups->contains($pickup)) {
            $this->pickups[] = $pickup;
            $pickup->setCustomer($this);
        }

        return $this;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

//    public function removePickup(Pickup $pickup): self
//    {
//        if ($this->pickups->contains($pickup)) {
//            $this->pickups->removeElement($pickup);
//            // set the owning side to null (unless already changed)
//            if ($pickup->getCustomer() === $this) {
//                $pickup->setCustomer(null);
//            }
//        }
//
//        return $this;
//    }

    public function jsonSerialize()
    {
        return [
          "id" => $this->getId(),
          "name" => $this->getName()
        ];
    }
}

