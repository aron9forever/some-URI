<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="App\Repository\ContainerRepository")
 */
class Container implements \JsonSerializable
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=11, nullable=true)
     * @Assert\Regex("/([a-zA-Z]{3})([UJZujz])(\d{6})(\d)/")
     */
    private $number;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\ContainerType", inversedBy="containers")
     * @ORM\JoinColumn(nullable=false)
     * @Assert\Valid
     */
    private $containerType;

    /**
     * @ORM\Column(type="decimal", precision=10, scale=2, nullable=true)
     */
    private $weight;

    /**
     * @ORM\OneToOne(targetEntity="App\Entity\Pickup", mappedBy="container", cascade={"persist", "remove"})
     */
    private $pickup;

    public function __construct(ContainerType $containerType = null)
    {
        $this->setContainerType($containerType);
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNumber(): ?string
    {
        return $this->number;
    }

    public function setNumber(string $number): self
    {
        $this->number = $number;

        return $this;
    }

    public function getContainerType(): ?ContainerType
    {
        return $this->containerType;
    }

    public function setContainerType(?ContainerType $containerType): self
    {
        $this->containerType = $containerType;

        return $this;
    }

    public function getWeight()
    {
        return $this->weight;
    }

    public function setWeight($weight): self
    {
        $this->weight = $weight;

        return $this;
    }

    public function getPickup(): ?Pickup
    {
        return $this->pickup;
    }

    public function setPickup(Pickup $pickup): self
    {
        $this->pickup = $pickup;

        // set the owning side of the relation if necessary
        if ($this !== $pickup->getContainer()) {
            $pickup->setContainer($this);
        }

        return $this;
    }

    public function jsonSerialize()
    {
        return [
            "id" => $this->getId(),
            "size" => $this->getContainerType()->jsonSerialize(),
            "number" => $this->getNumber(),
            "weight" => $this->getWeight()
        ];
    }
}
