<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="App\Repository\PickupRepository")
 */
class Pickup implements \JsonSerializable
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     * @Groups({"pickup_minimal"})
     */
    private $id;

    /**
     * @ORM\Column(type="datetime")
     * @Assert\NotBlank
     * @Assert\DateTime
     * @Groups({"pickup_minimal"})
     */
    private $date;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\CustomerParty", inversedBy="pickups", fetch="EAGER")
     * @ORM\JoinColumn(nullable=false)
     * @Assert\Valid
     * @Groups({"pickup_minimal"})
     */
    private $customer;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\WarehouseParty", inversedBy="pickups", fetch="EAGER")
     * @ORM\JoinColumn(nullable=false)
     * @Assert\Valid
     * @Groups({"pickup_minimal"})
     */
    private $warehouse;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\HaulierParty", inversedBy="pickups", fetch="EAGER")
     * @ORM\JoinColumn(nullable=false)
     * @Assert\Valid
     * @Groups({"pickup_minimal"})
     */
    private $haulier;

    /**
     * @ORM\Column(type="datetime")
     * @ORM\Version
     * @Groups({"pickup_minimal"})
     */
    private $createdAt;

    /**
     * @ORM\Column(type="datetime")
     * @ORM\Version
     * @Groups({"pickup_minimal"})
     */
    private $updatedAt;

    /**
     * @ORM\OneToOne(targetEntity="App\Entity\Container", inversedBy="pickup", cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     * @Assert\Valid
     */
    private $container;

    public function __construct()
    {
        $this->setCreatedAt(new \DateTime('now'));
        $this->setUpdatedAt(new \DateTime('now'));
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getCustomer(): ?Party
    {
        return $this->customer;
    }

    public function setCustomer(?Party $customer): self
    {
        $this->customer = $customer;

        return $this;
    }

    public function getWarehouse(): ?Party
    {
        return $this->warehouse;
    }

    public function setWarehouse(?Party $warehouse): self
    {
        $this->warehouse = $warehouse;

        return $this;
    }

    public function getHaulier(): ?Party
    {
        return $this->haulier;
    }

    public function setHaulier(?Party $haulier): self
    {
        $this->haulier = $haulier;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTimeInterface $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function jsonSerialize()
    {
        return [
            "id" => $this->getId(),
            "date" => $this->getDate()->format(DATE_ISO8601),
            "customer" => $this->getCustomer()->jsonSerialize(),
            "warehouse" => $this->getWarehouse()->jsonSerialize(),
            "haulier" => $this->getHaulier()->jsonSerialize(),
            "container" => $this->getContainer()->jsonSerialize(),
            "created_at" => $this->getCreatedAt(),
            "updated_at" => $this->getUpdatedAt()
        ];
    }

    public function getContainer(): ?Container
    {
        return $this->container;
    }

    public function setContainer(Container $container): self
    {
        $this->container = $container;

        return $this;
    }
}
