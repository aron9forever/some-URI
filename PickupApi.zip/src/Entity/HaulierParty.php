<?php


namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity()
 */
class HaulierParty extends Party
{
    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Pickup", mappedBy="haulier", fetch="LAZY")
     */
    protected $pickups;
}
